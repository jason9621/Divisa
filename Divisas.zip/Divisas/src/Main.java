import java.util.*;

public class Main {

    public static void main(String[] args) {

        System.out.println("Dígita la divisa en Dólares");
        Scanner divisa1 = new Scanner(System.in);
        double CambioDivsa =  (divisa1.nextDouble() * 525);

        System.out.println("Tu cambio a moneda es:" + "₡"+CambioDivsa);

    }
}